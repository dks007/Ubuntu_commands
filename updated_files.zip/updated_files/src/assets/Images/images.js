import logo from './Logo.svg'
import profile from './profile.jpg'
import adicon from './ad_icon.svg'
import loginBackground from './login_bg.jpg'
import loginIcon from './login_icon.svg'
import error404 from './404.png'

export { logo, profile, adicon, loginBackground, loginIcon, error404 }
