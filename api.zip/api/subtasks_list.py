# Your JSON data
# Your JSON data
subtasks_array = [
        {
            "id": "1980167",
            "key": "BE6000056495-16",
            "self": "https://ifsdev.atlassian.net/rest/api/3/issue/1980167",
            "fields": {
                "summary": "SAA10 Solution Adoption Best Practices for Future Releases",
                "status": {
                    "self": "https://ifsdev.atlassian.net/rest/api/3/status/11301",
                    "description": "",
                    "iconUrl": "https://ifsdev.atlassian.net/images/icons/statuses/generic.png",
                    "name": "Not Started",
                    "id": "11301",
                    "statusCategory": {
                        "self": "https://ifsdev.atlassian.net/rest/api/3/statuscategory/2",
                        "id": 2,
                        "key": "new",
                        "colorName": "blue-gray",
                        "name": "To Do"
                    }
                },
                "priority": {
                    "self": "https://ifsdev.atlassian.net/rest/api/3/priority/4",
                    "iconUrl": "https://ifsdev.atlassian.net/images/icons/priorities/minor.svg",
                    "name": "Three",
                    "id": "4"
                },
                "issuetype": {
                    "self": "https://ifsdev.atlassian.net/rest/api/3/issuetype/11500",
                    "id": "11500",
                    "description": "",
                    "iconUrl": "https://ifsdev.atlassian.net/rest/api/2/universal_avatar/view/type/issuetype/avatar/18776?size=medium",
                    "name": "Development Sub-task",
                    "subtask": True,
                    "avatarId": 18776,
                    "hierarchyLevel": -1
                }
            }
        },
        {
            "id": "1980168",
            "key": "BE6000056495-17",
            "self": "https://ifsdev.atlassian.net/rest/api/3/issue/1980168",
            "fields": {
                "summary": "SAA10 Solution Adoption Best Practices for Future Releases",
                "status": {
                    "self": "https://ifsdev.atlassian.net/rest/api/3/status/11301",
                    "description": "",
                    "iconUrl": "https://ifsdev.atlassian.net/images/icons/statuses/generic.png",
                    "name": "Not Started",
                    "id": "11301",
                    "statusCategory": {
                        "self": "https://ifsdev.atlassian.net/rest/api/3/statuscategory/2",
                        "id": 2,
                        "key": "new",
                        "colorName": "blue-gray",
                        "name": "To Do"
                    }
                },
                "priority": {
                    "self": "https://ifsdev.atlassian.net/rest/api/3/priority/4",
                    "iconUrl": "https://ifsdev.atlassian.net/images/icons/priorities/minor.svg",
                    "name": "Three",
                    "id": "4"
                },
                "issuetype": {
                    "self": "https://ifsdev.atlassian.net/rest/api/3/issuetype/11500",
                    "id": "11500",
                    "description": "",
                    "iconUrl": "https://ifsdev.atlassian.net/rest/api/2/universal_avatar/view/type/issuetype/avatar/18776?size=medium",
                    "name": "Development Sub-task",
                    "subtask": True,
                    "avatarId": 18776,
                    "hierarchyLevel": -1
                }
            }
        }
    ]



def extract_subtasks_data(subtasks):
    # Check if "subtasks" is not empty
    if subtasks:
        # Extracting key and summary of subtasks
        subtasks_data = []
        for subtask in subtasks:
            subtask_data = {
                "key": subtask.get("key", ""),
                "summary": subtask.get("fields", {}).get("summary", "")
            }
            subtasks_data.append(subtask_data)
        return subtasks_data
    else:
        return []

# Example usage:
# Your "subtasks" array as an argument


# Get the array of objects
result = extract_subtasks_data(subtasks_array)

# Displaying the collected data
print(result)
