import requests
from flask import Flask, redirect, request, session
from flask_session import Session
from hashlib import sha256
import base64
import secrets

app = Flask(__name__)

# Set a secret key for the session
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

# Set up Flask-Session
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# Replace with your application's credentials
CLIENT_ID = 'eb400c29-d53e-4b0b-a1f9-f60ce4eaf440'
CLIENT_SECRET = 'Mmr8Q~k3asskKV4ZAFHS8KPa5iWx6EBBSWR3ia9X'
REDIRECT_URI = 'http://localhost:5000/callback'
TENANT_ID = '2fc44a20-542d-4574-a028-c27cc470695a'
SCOPE = 'Files.ReadWrite.All'

# OneDrive API endpoints
BASE_URL = 'https://graph.microsoft.com/v1.0/me/drive/root'
FOLDER_NAME = 'dks_onedrive'
DOCUMENT_NAME = 'dilip_onedrive.docx'

# Function to get the access token using the OAuth 2.0 Authorization Code Grant Flow
def get_access_token(client_id, client_secret, redirect_uri, tenant_id, authorization_code):
    token_url = f'https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    data = {
        'grant_type': 'authorization_code',
        'client_id': client_id,
        'client_secret': client_secret,
        'code': authorization_code,
        'redirect_uri': redirect_uri,
    }

    response = requests.post(token_url, headers=headers, data=data)
    return response.json().get('access_token')

# Function to create a folder in OneDrive
def create_folder(access_token, folder_name):
    folder_url = f'{BASE_URL}/{folder_name}'
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json',
    }

    response = requests.put(folder_url, headers=headers)
    return response.json()

# Function to upload a document to OneDrive
def upload_document(access_token, folder_name, document_name, content):
    folder_url = f'{BASE_URL}/{folder_name}'
    upload_url = f'{folder_url}/{document_name}'
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'text/plain',
    }

    response = requests.put(upload_url, headers=headers, data=content)
    return response.json()

@app.route('/login')
def login():
    # Generate a random code verifier
    code_verifier = secrets.token_urlsafe(64)
    
    # Calculate the code challenge
    code_challenge = base64.urlsafe_b64encode(sha256(code_verifier.encode()).digest()).rstrip(b'=').decode('utf-8')

    # Store the code verifier in the session for later use in the callback
    session['code_verifier'] = code_verifier

    authorization_url = (
        f'https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/authorize?'
        f'client_id={CLIENT_ID}&response_type=code&redirect_uri={REDIRECT_URI}&response_mode=query&scope={SCOPE}&state=RANDOM_VALUE&'
        f'code_challenge={code_challenge}&code_challenge_method=S256'
    )
    return redirect(authorization_url)

@app.route('/callback')
def callback():
    authorization_code = request.args.get('code')
    # Use the authorization code to obtain the access token
    access_token = get_access_token(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI, TENANT_ID, authorization_code)
    # Now you can use the access token to make requests to the OneDrive API
    create_folder(access_token, FOLDER_NAME)
    upload_document(access_token, FOLDER_NAME, DOCUMENT_NAME, 'Document content here')
    return 'Success!'

if __name__ == '__main__':
    app.run(debug=True)
