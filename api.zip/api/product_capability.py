import json

# Sample JSON data
sample_json = '''
{
    "version": 1,
    "type": "doc",
    "content": [
      {
        "type": "paragraph",
        "content": [
          {
            "type": "text",
            "text": "Primary industry: Manufacturing "
          },
          {
            "type": "hardBreak"
          },
          {
            "type": "text",
            "text": "Product: IFS Cloud 22"
          },
          {
            "type": "hardBreak"
          },
          {
            "type": "text",
            "text": "Current software version: 22R2"
          },
          {
            "type": "hardBreak"
          },
          {
            "type": "text",
            "text": "Frequency: NA "
          },
          {
            "type": "hardBreak"
          },
          {
            "type": "text",
            "text": "Prerequisite Information: Description and what's new in IFS - Maintenance - 200 SUN"
          }
        ]
      }
    ]
}
'''

# Load JSON data
data = json.loads(sample_json)

# Function to extract values without using regular expressions
def extract_values(json_data):
    capability = None
    product_version = None
    product_name = None
    frequency = None

    for content_item in json_data.get("content", []):
        if content_item.get("type") == "paragraph":
            text_items = [item.get("text", "") for item in content_item.get("content", [])]

            for i in range(len(text_items)):
                line = text_items[i].strip()

                if line.lower().startswith("primary industry:"):
                    capability = line.split(":")[1].strip()

                if line.lower().startswith("product:"):
                    product_line = line.split(":")[1].strip()
                    if i + 1 < len(text_items) and not text_items[i + 1].strip().lower().startswith("current software version:"):
                        product_parts = product_line.split()
                        product_name = product_line if not any(part.replace('.', '', 1).isdigit() for part in product_parts) else " ".join(product_parts[:-1])
                        product_version = next((part for part in product_parts if part.replace('.', '', 1).isdigit()), "NA")
                    else:
                        product_name = product_line
                        product_version = "NA"

                if line.lower().startswith("frequency:"):
                    frequency = line.split(":")[1].strip()

    return capability, product_name, product_version, frequency

# Extract values
capability, product_name, product_version, frequency = extract_values(data)

# Print the extracted values
print("Capability:", capability)
print("Product Name:", product_name)
print("Product Version:", product_version)
print("Frequency:", frequency)
