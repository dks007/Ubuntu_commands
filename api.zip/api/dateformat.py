from datetime import datetime

def format_date(input_date, input_format="%Y-%m-%dT%H:%M:%S.%f%z"):
    if isinstance(input_date, datetime):
        # If the input is already a datetime object, just format it
        formatted_date = input_date.strftime("%-d %b %Y")
        return formatted_date

    try:
        # Parse the input date string
        parsed_date = datetime.strptime(input_date, input_format)

        # Truncate microseconds and format the date using f-string
        formatted_date = f"{parsed_date.day} {parsed_date.strftime('%b %Y')}"
        return formatted_date

    except ValueError as e:
        # Handle the case where the input date string is not in the expected format
        print(f"Error: {e}")
        return None

# Example usage:
date_string1 = "2023-11-27T12:26:47.239000+01:00"
formatted_date1 = format_date(date_string1)

date_string2 = "2023-11-27T07:54:59.938+0100"
formatted_date2 = format_date(date_string2, "%Y-%m-%dT%H:%M:%S.%f%z")

if formatted_date1:
    print(formatted_date1)

if formatted_date2:
    print(formatted_date2)
