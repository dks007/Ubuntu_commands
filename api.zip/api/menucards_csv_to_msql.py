from openpyxl import load_workbook
import pymysql

# Replace these with your MySQL database details
db_host = 'localhost'
db_user = 'root'
db_password = ''
db_name = 'ifsreporting_local'

# Replace this with the path to your Excel file
excel_file_path = 'data_mapping_1.xlsx'

# Specify the sheet name you want to read
sheet_name = 'menu_cards'

# Create a MySQL connection
connection = pymysql.connect(
    host=db_host,
    user=db_user,
    password=db_password,
    database=db_name
)

# Create a cursor object
cursor = connection.cursor()

# Read data from the Excel file
workbook = load_workbook(excel_file_path, read_only=True)
sheet = workbook[sheet_name]

# Extract and insert data into MySQL table
table_name = 'dashboard_menucards'
for row in sheet.iter_rows(min_row=2, values_only=True):  # Assuming data starts from row 2
    # Assuming your table structure is (id, menu_card, sdo, email)
    menu_card = row[0]
    menu_description = row[1]
    menu_template = row[2]
    
    # Check if menu_card is None or empty
    if menu_card is None or menu_card == '':
        print(f"Skipping row due to missing or empty 'menu_card'.")
        continue
    
    # Construct the SQL INSERT statement with placeholders excluding the 'email' column
    sql = f"INSERT IGNORE INTO {table_name} (menu_card, menu_description, menu_template ) VALUES (%s, %s, %s)"
    
    # Execute the SQL statement with parameterized values
    cursor.execute(sql, (menu_card, menu_description, menu_template))
    
# Commit the changes and close the connections
connection.commit()
cursor.close()
connection.close()

print(f"Data from sheet '{sheet_name}' successfully loaded into MySQL table '{table_name}'.")
