from openpyxl import load_workbook
import pymysql

# Replace these with your MySQL database details
db_host = 'localhost'
db_user = 'root'
db_password = ''
db_name = 'ifsreporting_local'

# Replace this with the path to your Excel file
excel_file_path = 'data_mapping_1.xlsx'

# Specify the sheet name you want to read
sheet_name = 'menu_sdo'

# Create a MySQL connection
connection = pymysql.connect(
    host=db_host,
    user=db_user,
    password=db_password,
    database=db_name
)

# Create a cursor object
cursor = connection.cursor()

# Read data from the Excel file
workbook = load_workbook(excel_file_path, read_only=True)
sheet = workbook[sheet_name]

# Extract and insert data into MySQL table
table_name = 'dashboard_menusdo'
for row in sheet.iter_rows(min_row=2, values_only=True):  # Assuming data starts from row 2
    # Assuming your table structure is (id, menu_card, sdo, email)
    menu_card = row[0]
    sdo = row[1]
    
    # Check if menu_card is None or empty
    if menu_card is None or menu_card == '':
        print(f"Skipping row due to missing or empty 'menu_card'.")
        continue
    
    # Construct the SQL INSERT statement with placeholders excluding the 'email' column
    sql = f"INSERT IGNORE INTO {table_name} (menu_card, sdo) VALUES (%s, %s)"
    
    # Execute the SQL statement with parameterized values
    cursor.execute(sql, (menu_card, sdo))
    
# Commit the changes and close the connections
connection.commit()
cursor.close()
connection.close()

print(f"Data from sheet '{sheet_name}' successfully loaded into MySQL table '{table_name}'.")
