import requests
from requests.auth import HTTPBasicAuth
import json, csv, time
from datetime import datetime

url = "https://ifsdev.atlassian.net/rest/api/3/search"
auth = HTTPBasicAuth("dilip.kumar.shrivastwa@ifs.com", "ATATT3xFfGF0p-FG8-lj6HsWs80g3AtzRePPZ4WDbZEq_ZlDJoEVV3zcusdMdiyGxn1do8ldFe4Tgy4OcC2gOc9yArvRSzZ24z13JqWPxKsJvvinVybUIwYdlnla8QErcuYl0XnMBvLc_Fn_sk2TntBf1Rj4DZ-hkL5FOr4xu5kDo9M2rna2vEQ=B3F4BE74")

#url = "https://dsklocal.atlassian.net/rest/api/3/search"
#auth = HTTPBasicAuth("dilip.ku.007@gmail.com", "ATATT3xFfGF0j4yujBnPZIYHC_W-CbbN24zUfJnpG6XsGcnR61B2WJVFFS4WowNFVtIY5OPKfuAi51lWTaE4nHCqhnW1SsBCRC_wFIQ2QJvDO0EBu3OkCR-Gbyz4pC6VGJGeXmi0BCrExXXO5sYA_cTLLG6Y6zL0z3neq6ZtCYqYhnyUuxv_X7E=0F5CA19B")

max_duration_seconds = 60
start_time = time.time()
headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"
}
# set the initial parameter

payload = {
    "expand": [
        "changelog"
    ],
    "jql": "issuetype in (Sub-task, Tasks) AND status in ('Awaiting Customer', 'In Process','In Review','Not Started') AND 'Service Category[Dropdown]' = 'Expert Services' AND assignee NOT in (EMPTY) order by created DESC",
    #"jql": "issuetype in (Sub-task, Tasks) AND status in ('Awaiting Customer', 'In Process','In Review','Not Started') order by created DESC",
    "fieldsByKeys": False,
    "fields": [
        "summary",
        "project",
        "customfield_16036",
        "assignee",
        "issuetype",
        "status",
        "parent",
        "created",
        "creator"
    ],
    "maxResults": 100,
    "startAt": 0
}
csv_file_path = "all_issue.csv"
# Write the header row
with open(csv_file_path, mode='a', encoding='utf-8', newline='') as csv_file:
    fieldnames = ["summary", "activity_short_name", "issue_id", "issue_key", "created", "changelog_assignee_created",
                  "creator", "project", "parent_key", "parent_summary", "project_key", "subtask", "assignee_name","assignee_email", "status"]
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    writer.writeheader()

while True:
    response = requests.request(
        "POST",
        url,
        headers=headers,
        auth=auth,
        data=json.dumps(payload),
        verify=False
    )
    # check the request response was successful
    if response.status_code == 200:
        # parse the JSON
        issues_data = json.loads(response.text)
        # Write the extracted fields for each issue to the CSV file
        with open(csv_file_path, mode='a', encoding='utf-8', newline='') as csv_file:
            fieldnames = ["summary", "activity_short_name", "issue_id", "issue_key", "created",
                          "changelog_assignee_created", "creator", "project", "parent_key", "parent_summary",
                          "project_key", "subtask", "assignee_name","assignee_email", "status"]
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)

            # write data for each issue
            for issue in issues_data['issues']:
                # Extract changelog data
                changelog = issue["changelog"]["histories"] if "changelog" in issue else None
                # Extract assignee and created date from changelog
                changelog_assignee_created = None
                if changelog:
                    for history in changelog:
                        for item in history["items"]:
                            if item["field"] == "assignee":
                                created_date_str = history["created"]
                                created_date = datetime.strptime(created_date_str, "%Y-%m-%dT%H:%M:%S.%f%z")
                                if changelog_assignee_created is None or created_date < changelog_assignee_created:
                                    changelog_assignee_created = created_date
                summary = issue["fields"]['summary']
                issue_id = issue["id"]
                issue_key = issue["key"]
                created = issue["fields"]['created']
                creator = issue["fields"]["creator"]["emailAddress"] if issue["fields"]["creator"] else None
                project = issue["fields"]['project']["name"]
                parent_key = issue["fields"]["parent"]["key"] if "parent" in issue["fields"] and issue["fields"]["parent"] else None
                parent_summary = issue["fields"]["parent"]["fields"]['summary'] if "parent" in issue["fields"] and issue["fields"]["parent"] else None
                project_key = issue["fields"]['project']["key"]
                subtask = issue["fields"]['issuetype']["subtask"]
                customfield_16036 = issue["fields"]["customfield_16036"]
                assignee_name = issue["fields"]["assignee"]["displayName"] if "assignee" in issue["fields"] and issue["fields"]["assignee"] else None
                assignee_email = issue["fields"]["assignee"]["emailAddress"] if "assignee" in issue["fields"] and issue["fields"]["assignee"] else None
                status = issue["fields"]['status']["name"]

                issue_fields = {
                    "summary": summary,
                    "activity_short_name": customfield_16036,
                    "issue_id": issue_id,
                    "issue_key": issue_key,
                    "created": created,
                    "changelog_assignee_created": changelog_assignee_created.isoformat() if changelog_assignee_created else None,
                    "creator": creator,
                    "project": project,
                    "parent_key": parent_key,
                    "parent_summary": parent_summary,
                    "project_key": project_key,
                    "subtask": subtask,
                    "assignee_name": assignee_name,
                    "assignee_email": assignee_email,
                    "status": status
                }
                writer.writerow(issue_fields)

        # check if there is more issue to retrieve
        if time.time() - start_time > max_duration_seconds:
            print("time exceeds!")
            break
        if issues_data['startAt'] + issues_data['maxResults'] < issues_data['total']:
            # increment the startAt parameter for next
            payload['startAt'] += issues_data['maxResults']
            print(payload['startAt'])
        else:
            # all issue has been retrieved
            break
        # print(f"CSV file '{csv_file_path}' has been created successfully!")
        print(f"CSV file has been created successfully!")    
    else:
        # print error if request was not successful
        print(f"Failed to retrieve data. Status code :{response.status_code}")
        # print(response.text)
        break


