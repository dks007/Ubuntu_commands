import re

menuList = ['QSM1', 'QSM2', 'QSM3', 'QSM4', 'QSM5', 'QSM6', 'QSM7', 'QSM8', 'QSM9', 'QSM10', 'QSM11', 'QSM12',
            'SAA1', 'SAA2', 'SAA3', 'SAA4', 'SAA5', 'SAA6', 'SAA7', 'SAA8', 'SAA9', 'SAA10', 'SAA11', 'SAA12', 'SAA13',
            'SAA14', 'SAA15', 'TAA1', 'TAA2', 'TAA3', 'TAA4', 'TAA5', 'TAA6', 'TAA7', 'TAA8','TAA89', 'EMA1', 'EMA2', 'EMA3',
            'EMA4', 'EMA5', 'EMA6', 'EMA7', 'EMA8', 'EMA9', 'EMA10', 'EMA11', 'EMA12', 'EMA13', 'EMA14']

matchStr1 = 'SAA3'

# Function to find the menu id and check for 'P' just after it in the activity short menu
def find_menuid_in_string(menu_list, match_str):
    # Normalize the format by removing leading zeros from numeric parts
    normalized_match_str = re.sub(r'(\D)0+(\d)', r'\1\2', match_str)
    
    matching_values = [menu_item for menu_item in menu_list if re.sub(r'(\D)0+(\d)', r'\1\2', menu_item) in normalized_match_str]
    
    if matching_values:
        menu_id = max(matching_values, key=len)
        index_of_match = normalized_match_str.find(menu_id)
        p_is_after_match = (index_of_match + len(menu_id) < len(normalized_match_str)) and (normalized_match_str[index_of_match + len(menu_id)] == 'P')
        return menu_id, p_is_after_match
    return None, False

# Find and print the result for matchStr1
menu_id, partner = find_menuid_in_string(menuList, matchStr1)

if menu_id is not None:
    print("Menu ID:", menu_id)
    print("Is 'P' just after the menu ID:", partner)
else:
    print("No matching menu ID found.")
