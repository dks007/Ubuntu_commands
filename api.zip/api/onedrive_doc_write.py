import requests
import logging

# Configure logging
#logging.basicConfig(level=logging.INFO)  # Adjust the level as needed

# Replace these values with your own
CLIENT_ID = 'eb400c29-d53e-4b0b-a1f9-f60ce4eaf440'
CLIENT_SECRET = 'Mmr8Q~k3asskKV4ZAFHS8KPa5iWx6EBBSWR3ia9X'
TENANT_ID = '2fc44a20-542d-4574-a028-c27cc470695a'
ACCESS_TOKEN_ENDPOINT = f'https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token'

# Replace with the user's principal name (email) or any other identifier you know
USER_PRINCIPAL_NAME = 'dilip.ku.007@gmail.com'  

# Microsoft Graph API endpoint for getting user information
#USER_INFO_ENDPOINT = f'https://graph.microsoft.com/v1.0/users/{USER_PRINCIPAL_NAME}'

USER_INFO_ENDPOINT = f'https://graph.microsoft.com/v1.0/users?$filter=userPrincipalName eq \'{USER_PRINCIPAL_NAME}\''



# OneDrive API endpoints
BASE_URL = 'https://graph.microsoft.com/v1.0/me/drive/root'
FOLDER_NAME = ''
DOCUMENT_NAME = 'dilip_onedrive.docx'

# Function to upload a document to OneDrive
def upload_document(access_token, folder_name, document_name, content):
    folder_url = f'{BASE_URL}/{folder_name}'
    upload_url = f'{folder_url}/{document_name}'
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'text/plain',
    }

    #response = requests.put(upload_url, headers=headers, data=content)
    try:
        response = requests.put(upload_url, headers=headers, data=content)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print('Error making the request:', e)
        return None
    
    return response.json()

def get_access_token():
    token_payload = {
        'grant_type': 'client_credentials',
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'scope': 'https://graph.microsoft.com/.default',
    }
    #response = requests.post(ACCESS_TOKEN_ENDPOINT, data=token_payload)
    
    try:
        response = requests.post(ACCESS_TOKEN_ENDPOINT, data=token_payload)
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
    except requests.exceptions.RequestException as e:
        print('Error making the request:', e)
        return None
    
    
    if response.status_code == 200:
        return response.json().get('access_token')
    else:
        print('Error getting access token:', response.text)
        return None

def get_user_id(access_token):
    headers = {
        'Authorization': 'Bearer ' + access_token,
    }
    response = requests.get(USER_INFO_ENDPOINT, headers=headers)
    if response.status_code == 200:
        user_info = response.json()
        user_id = user_info.get('id')
        return user_id
    else:
        print('Error getting user information:', response.text)
        return None

if __name__ == '__main__':
    access_token = get_access_token()
    print("Access Token-->",access_token)
    if access_token:
       upload_response = upload_document(access_token, FOLDER_NAME, DOCUMENT_NAME, 'Document content here')
       print(upload_response)
