from jira import JIRA

# Replace these values with your Jira server details
JIRA_SERVER = 'https://dsklocal.atlassian.net'
JIRA_USERNAME = 'dilip.ku.007@gmail.com'
JIRA_PASSWORD = 'ATATT3xFfGF0WfP3Y8T7h2hbqpXAlogMNENL-QvKeL5O5kLXnhNc9UGZLYolR6Inat3HOE_wy1Wx_LhvU-xyVG_4oEs4R3_3cpe2FTduvpKenzUnuMNd4K65tyFAY08-gKDsXovOiy5Ako154-3fgFQ1JTjMG1bwx7nB9tiRuvS8hdLIGjx5wdU=4E400EA8'

# Connect to Jira
options = {
    'server': JIRA_SERVER,
    'verify': True  # Set to True if your Jira instance has a valid SSL certificate
}
jira = JIRA(options, basic_auth=(JIRA_USERNAME, JIRA_PASSWORD))

# JQL query to get all issues from all projects
jql_query = 'project is not EMPTY'

# Fetch issues based on the JQL query
issues = jira.search_issues(jql_query, maxResults=False, fields=[
    'id', 'key', 'summary', 'status', 'assignee', 'created', 'issuetype', 'parent'
])

# Print header
print("{:<10} {:<15} {:<40} {:<20} {:<20} {:<20} {:<20} {:<20}".format(
    "ID", "Key", "Summary", "Status", "Assignee Name", "Assignee Email", "Parent ID", "Created Date"))

# Print each issue's information
for issue in issues:
    assignee_name = getattr(issue.fields.assignee, 'displayName', '') if issue.fields.assignee else ''
    assignee_email = getattr(issue.fields.assignee, 'emailAddress', '') if issue.fields.assignee else ''
    parent_id = getattr(issue.fields, 'parent', None)  # Get the 'parent' attribute

    # If the issue has a parent, extract its ID
    parent_id = parent_id.id if parent_id else ''

    created_date = issue.fields.created
    status_name = getattr(issue.fields.status, 'name', '') if issue.fields.status else ''  # Get the 'name' attribute of Status

    # Ensure that all variables are non-None before formatting the string
    if None not in [issue.id, issue.key, issue.fields.summary, status_name, assignee_name, assignee_email, parent_id, created_date]:
        print("{:<10} {:<15} {:<40} {:<20} {:<20} {:<20} {:<20} {:<20}".format(
            issue.id, issue.key, issue.fields.summary, status_name, assignee_name,
            assignee_email, parent_id, created_date))
    else:
        print("One or more fields are None for issue {}".format(issue.key))
