import requests
from requests.auth import HTTPBasicAuth
import json
import csv

url = "https://ifsdev.atlassian.net/rest/api/3/search"
auth = HTTPBasicAuth("dilip.kumar.shrivastwa@ifs.com", "ATATT3xFFGF0p-FG8-1j6HsWs80g3AtzRePPZ")
headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"  # Specify the content type for the request
}

# Specify the JQL query to filter tasks and subtasks
jql_query = "issuetype in (Task, Sub-task)"

# Set the initial parameters for the request
params = {
    "maxResults": 100,  # Adjust the number of results per page as needed
    "startAt": 0
}

# Set the request body with the JQL query
payload = {
    "jql": jql_query,
    "fields": ["assignee", "email", "project", "status","parent"]
}

csv_file_path = "issue_data.csv"

# Write the header row to the CSV file with UTF-8 encoding
with open(csv_file_path, mode='w', newline='', encoding='utf-8') as csv_file:
    fieldnames = ["assignee", "email", "project", "status","parent"]
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    writer.writeheader()

while True:
    # Make the POST request with the current parameters
    response = requests.request(url, headers=headers, auth=auth, params=params, data=payload)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the JSON response and extract the desired fields for each issue
        issues_data = json.loads(response.text)

        # Write the extracted fields for each issue to the CSV file with UTF-8 encoding
        with open(csv_file_path, mode='a', newline='', encoding='utf-8') as csv_file:
            fieldnames = ["assignee", "email", "project", "status"]
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)

            # Write data for each issue
            for issue in issues_data["issues"]:
                assignee = issue["fields"]["assignee"]["displayName"] if issue["fields"]["assignee"] else None
                email = issue["fields"]["assignee"]["emailAddress"] if issue["fields"]["assignee"] else None
                project = issue["fields"]["project"]["name"]
                parent_key = issue["fields"]["parent"]["key"]
                status = issue["fields"]["status"]["name"]

                issue_fields = {
                    "assignee": assignee,
                    "email": email,
                    "project": project,
                    "parent_key": parent_key,
                    "status": status
                }
                writer.writerow(issue_fields)

        # Check if there are more issues to retrieve
        if issues_data["startAt"] + issues_data["maxResults"] < issues_data["total"]:
            # Increment the startAt parameter for the next page
            params["startAt"] += issues_data["maxResults"]
        else:
            # All issues have been retrieved
            break
    else:
        # Print an error message if the request was not successful
        print(f"Failed to retrieve data. Status code: {response.status_code}")
        try:
            error_data = json.loads(response.text)
            print("Error details:", error_data)
        except json.JSONDecodeError:
            print("Error details:", response.text)
        break

print(f"CSV file '{csv_file_path}' has been created successfully.")
