import redis
import os
from elasticsearch import Elasticsearch
#from rediscluster import StrictRedisCluster
redisconfig = {
    'host': '10.201.201.64',
    'port': 6400,
    'db': 0,
    'password':'',
    'socket_timeout':None,
    'charset':'utf-8'
}
secret_key = 'YXNuc2prc2RranNkc2Rqd3VxaTMyOTg5'
r = redis.StrictRedis(**redisconfig)
FILEPATH = os.path.join(os.path.abspath(os.sep),"home","developer","p1_py","sf")
USERLOGSPATH = os.path.join(os.path.abspath(os.sep),"home","developer","p1_py","logs","userlogs")
EVENTLOGSPATH = os.path.join(os.path.abspath(os.sep),"home","developer","p1_py","logs","eventlogs")
SCRIPTLOGSPATH = os.path.join(os.path.abspath(os.sep),"home","developer","p1_py","logs","scriptlogs")
FILEFORMAT = "*.log*"
LOGFILEFORMAT = "*.log*"
#es = Elasticsearch([{'host': 'localhost', 'port': 7205, 'timeout': 600}])
es = Elasticsearch([{'host': '10.201.201.63', 'port': 7205, 'timeout': 300},{'host': '10.201.201.65', 'port': 7205, 'timeout': 300}])
_debug_log = True
