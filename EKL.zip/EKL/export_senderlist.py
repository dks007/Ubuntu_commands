# -*- coding: utf-8 -*-
from multiprocessing import Pool as ThreadPool
from time import gmtime, strftime
import os, sys
import time,datetime, json
from datetime import datetime
sys.path.append('/home/developer/p1_py/')
import filerotater
import config
## Make the Pool of workers
now  = datetime.now()
dt   = now.strftime("%Y%m%d")
#dt   = now.strftime("%Y%m%d%H")
SENDERDATAPATH = os.path.join(os.path.abspath(os.sep),"home","developer","p1_py","backup","senderlist",dt)
#SENDERDATAPATH = os.path.join(os.path.abspath(os.sep),"Python","Python35","ULTRON_EXPORT_IMPORT","backup","senderlist",dt)
es   = config.es
index_senderlist = 'senderzinglist',    # index name 
type_senderlist = 'znl',                # type name
bulkfname='senderzinglistbulk'+dt       # file name
#***********************Function Get all data***********************************
def get_getsenderlistExport():
    fname=bulkfname
    makedirpath(SENDERDATAPATH)
    file_ext='.log'
    # 50 MB => 52428800 file break for 100 MB => 102428800  , 500 MB => 502428800
    bulkFile = filerotater.RotatingFile(directory=SENDERDATAPATH, filename=fname,
                                            max_files=sys.maxsize,
                                            max_file_size=502428800)
    qbody ={"query": {"match_all": {}}}
    page = es.search(
        index = index_senderlist,
        doc_type = type_senderlist,
        scroll = '5m',
        size = 10000,
        #search_type = 'scan',
        body = qbody)
    sid = page['_scroll_id']
    hits = total_size = page['hits']['total']
    scroll_size = len(page['hits']['hits'])
    while (scroll_size > 0):
        for doc in page['hits']['hits']:
            keyAr=''
            lobj = {}
            keyAr = doc['_source'].keys()
            for kv in keyAr:
                #print(keyAr)
                lobj[kv]  = (doc['_source'][kv])

            jdata = json.dumps(lobj)
            dataid = getbulkid(doc['_id'])
            bulkFile.write(dataid + "\n" + jdata + "\n")
        page = es.scroll(scroll_id = sid, scroll = '5m')
        sid = page['_scroll_id']
        # Get the number of results that we returned in the last scroll
        scroll_size = len(page['hits']['hits'])
        #if zid !='':


#********************************End : ******************************

def decodeJson(line):
    try:
        data = codecs.encode(line, 'utf-8')
        d = data.decode('unicode-escape')
        el = json.loads(d, 'utf-8')
        cjson = a = el['json']

        if isinstance(a, str):
            cjson =  json.loads(a, 'utf-8')
        return cjson
    except:
        return None
def getbulkid(pid):
    obj = {}
    #ustr = uid_str[9:]
    #idobj["_id"] = ""
    obj["index"] = {"_id":pid}
    return json.dumps(obj)

def makedirpath(path):
    if not (os.path.isdir(path)):
        try:
            os.makedirs(path)
        except OSError as exception:
            if exception.errno != errno.EEXIST:
                raise

if __name__ == '__main__':

    start = time.time()
    get_getsenderlistExport()
    end = time.time()
    print (end - start)
#bulkpost.initeventlogpost()
